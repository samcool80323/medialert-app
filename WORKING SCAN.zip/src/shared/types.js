"use strict";
// Shared types between frontend and backend
Object.defineProperty(exports, "__esModule", { value: true });
